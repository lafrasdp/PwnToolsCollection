﻿#Enum

Enum PromptBehavior{
    Auto = 0
    Always = 1
    Never = 2
    RefreshSession = 3
    SelectAccount = 4
}